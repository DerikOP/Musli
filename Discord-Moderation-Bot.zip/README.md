# Musli 

#### This Is Musli Mark 1
* Underdevelopment
* Trying my best
* Got some templates and made some myself
* idk how to use github so sorry

#### Owner Info
* Author: `Derik Khera`
* yea thats it


#### Commands
* Ban | Unban
* Deafen | Undeafen
* DisableModLogChannel | SetModLogChannel
* DisableMuteRole | SetMuteRole
* Dm 
* Hackban/Forceban | Unban
* Kick
* Lock channel | Unlock
* Lockdown [Only for emergency scenarios] | Unlock
* Mute | Unmute
* Purge
* RoleAdd
* RoleInfo
* RoleMemberInfo
* SetNick
* Slowmode
* Svr [Server Region change]
* VoiceMove [Move a peerson from one vc to another]
* Warn
* Whois

# Contributors:
 * [Manav Garg](https://github.com/ManavvGarg) -Code and Commands
 
